from django.urls import path, include
from . import views

urlpatterns = [
    path('',views.index, name='ShopHome'),
    path('productview/<int:myid>',views.productview, name='ProductView'),
    path('shop/checkout/',views.checkout, name='Checkout'),
    path('login/',views.login_user,name='login'),
	path('logout/',views.logout_user,name='logout'),
	path('register/',views.register_user,name='register'),
	path('edit_profile/',views.edit_profile,name='edit_profile'),
	path('change_password/',views.change_password,name='change_password'),
    
]
